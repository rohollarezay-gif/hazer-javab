package com.hazerjavab.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val picker = 20
    private val worker = Executors.newSingleThreadExecutor()
    private var textPdf = ""
    private lateinit var output: TextView
    private lateinit var key: EditText
    private lateinit var offline: RadioButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 22)
            setBackgroundColor(Color.rgb(242,247,255))
        }
        fun label(s: String, size: Float, color: Int = Color.DKGRAY) = TextView(this).apply {
            text=s; textSize=size; setTextColor(color); gravity=Gravity.CENTER
        }
        layout.addView(label("حاضر جواب", 30f, Color.rgb(30,95,195)))
        layout.addView(label("دستیار هوشمند حل سؤالات PDF", 15f))
        val choose = Button(this).apply { text="انتخاب فایل PDF"; setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="application/pdf" }, picker)
        }}
        layout.addView(choose)
        val online = RadioButton(this).apply { text="آنلاین با هوش مصنوعی"; isChecked=true }
        offline = RadioButton(this).apply { text="آفلاین: استخراج متن و سؤال‌های احتمالی" }
        val group = RadioGroup(this).apply { orientation=RadioGroup.VERTICAL; addView(online); addView(offline) }
        layout.addView(group)
        key = EditText(this).apply { hint="کلید API برای حالت آنلاین"; inputType=129 }
        layout.addView(key)
        val run = Button(this).apply { text="استخراج و پاسخ"; setOnClickListener { processPdf() } }
        layout.addView(run)
        output = label("ابتدا یک فایل PDF انتخاب کنید.", 15f)
        output.gravity=Gravity.START
        output.setPadding(12,18,12,18)
        output.setBackgroundColor(Color.WHITE)
        layout.addView(output)
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==picker && resultCode==RESULT_OK) {
            val uri=data?.data ?: return
            output.text="در حال استخراج متن PDF..."
            worker.execute {
                try {
                    contentResolver.openInputStream(uri).use { stream ->
                        val doc=PDDocument.load(stream)
                        textPdf=try { PDFTextStripper().getText(doc) } finally { doc.close() }
                    }
                    runOnUiThread { output.text="PDF آماده است؛ متن استخراج‌شده: ${textPdf.length} نویسه." }
                } catch(e:Exception) { runOnUiThread { output.text="خطا: ${e.message}\nفایل‌های اسکن‌شده به OCR نیاز دارند." } }
            }
        }
    }

    private fun processPdf() {
        if(textPdf.isBlank()) { output.text="اول یک PDF متنی انتخاب کنید."; return }
        if(offline.isChecked) {
            val qs=textPdf.lines().map{it.trim()}.filter{it.length>10 && (it.contains("?") || it.contains("؟") || it.startsWith("سوال") || it.startsWith("سؤال") || it.startsWith("تمرین"))}.distinct()
            output.text=if(qs.isEmpty()) "سؤال مشخصی پیدا نشد. متن استخراج شد اما پاسخ هوشمند آفلاین در این نسخه فعال نیست.\n\n"+textPdf.take(3500)
            else "سؤال‌های احتمالی (حالت آفلاین فقط استخراج می‌کند):\n\n"+qs.take(80).mapIndexed{i,s -> "${i+1}. $s"}.joinToString("\n\n")
            return
        }
        val api=key.text.toString().trim()
        if(api.isEmpty()) { output.text="برای حالت آنلاین کلید API را وارد کنید."; return }
        output.text="در حال دریافت پاسخ..."
        worker.execute {
            try {
                val body=JSONObject().apply {
                    put("model","gpt-5.5")
                    put("input",JSONArray().put(JSONObject().apply {
                        put("role","user")
                        put("content",JSONArray().put(JSONObject().apply {
                            put("type","input_text")
                            put("text","سؤال‌های متن زیر را استخراج کن و به فارسی تشریحی پاسخ بده:\n"+textPdf.take(45000))
                        }))
                    }))
                }
                val c=URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection
                c.requestMethod="POST"; c.setRequestProperty("Authorization","Bearer $api")
                c.setRequestProperty("Content-Type","application/json"); c.connectTimeout=30000; c.readTimeout=120000; c.doOutput=true
                OutputStreamWriter(c.outputStream,Charsets.UTF_8).use{it.write(body.toString())}
                val stream=if(c.responseCode in 200..299)c.inputStream else c.errorStream
                val raw=BufferedReader(InputStreamReader(stream,Charsets.UTF_8)).use{it.readText()}
                if(c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}: $raw")
                val arr=JSONObject(raw).optJSONArray("output") ?: JSONArray()
                val answers=mutableListOf<String>()
                for(i in 0 until arr.length()) {
                    val parts=arr.optJSONObject(i)?.optJSONArray("content") ?: continue
                    for(j in 0 until parts.length()) {
                        val p=parts.optJSONObject(j) ?: continue
                        if(p.optString("type")=="output_text") answers.add(p.optString("text"))
                    }
                }
                runOnUiThread { output.text=answers.joinToString("\n").ifBlank{"پاسخی دریافت نشد."} }
            } catch(e:Exception) { runOnUiThread { output.text="خطا: ${e.message}" } }
        }
    }
}
